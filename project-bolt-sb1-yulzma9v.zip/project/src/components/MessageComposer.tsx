import React, { useState } from 'react';
import { Send, Paperclip, Image, Video, FileText, X, Eye, AlertCircle, CheckCircle } from 'lucide-react';
import type { Contact } from '../lib/supabase';

interface MessageComposerProps {
  contacts: Contact[];
  onSendMessage: (messageData: { text: string; files: File[] }) => Promise<any>;
  loading?: boolean;
}

const MessageComposer: React.FC<MessageComposerProps> = ({ contacts, onSendMessage, loading = false }) => {
  const [message, setMessage] = useState('');
  const [attachedFiles, setAttachedFiles] = useState<File[]>([]);
  const [previewFile, setPreviewFile] = useState<File | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    setAttachedFiles(prev => [...prev, ...files]);
  };

  const handleRemoveFile = (index: number) => {
    setAttachedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSend = async () => {
    if ((message.trim() || attachedFiles.length > 0) && contacts.length > 0) {
      try {
        setError(null);
        setSuccess(null);
        
        const result = await onSendMessage({ text: message, files: attachedFiles });
        
        if (result.success) {
          setMessage('');
          setAttachedFiles([]);
          setSuccess(`Message sent successfully! ${result.summary.sent} sent, ${result.summary.failed} failed.`);
        } else {
          setError(result.error || 'Failed to send message');
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to send message');
      }
    }
  };

  const getFileIcon = (file: File) => {
    if (file.type.startsWith('image/')) return <Image size={16} className="text-blue-600" />;
    if (file.type.startsWith('video/')) return <Video size={16} className="text-purple-600" />;
    return <FileText size={16} className="text-gray-600" />;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const canPreviewFile = (file: File) => {
    return file.type.startsWith('image/') || file.type.startsWith('video/') || file.type === 'application/pdf';
  };

  const renderPreview = () => {
    if (!previewFile) return null;

    if (previewFile.type.startsWith('image/')) {
      return <img src={URL.createObjectURL(previewFile)} alt="Preview" className="max-w-full max-h-96 object-contain rounded-lg" />;
    }
    
    if (previewFile.type.startsWith('video/')) {
      return <video src={URL.createObjectURL(previewFile)} controls className="max-w-full max-h-96 rounded-lg" />;
    }
    
    if (previewFile.type === 'application/pdf') {
      return <iframe src={URL.createObjectURL(previewFile)} className="w-full h-96 rounded-lg" />;
    }
    
    return <div className="p-8 text-center text-gray-500">Preview not available for this file type</div>;
  };

  return (
    <div className="p-6">
      <div className="flex items-center gap-2 mb-6">
        <Send className="text-[#3a6f78]" size={24} />
        <h2 className="text-2xl font-bold text-gray-900">Compose WhatsApp Message</h2>
      </div>

      {/* Success Display */}
      {success && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6 flex items-center gap-2">
          <CheckCircle size={20} className="text-green-600" />
          <p className="text-green-700">{success}</p>
          <button 
            onClick={() => setSuccess(null)}
            className="ml-auto text-green-600 hover:text-green-800"
          >
            ×
          </button>
        </div>
      )}

      {/* Error Display */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-center gap-2">
          <AlertCircle size={20} className="text-red-600" />
          <p className="text-red-700">{error}</p>
          <button 
            onClick={() => setError(null)}
            className="ml-auto text-red-600 hover:text-red-800"
          >
            ×
          </button>
        </div>
      )}

      {/* Recipients Info */}
      <div className="bg-gradient-to-r from-[#3a6f78]/10 to-[#3a6f78]/5 border border-[#3a6f78]/20 rounded-lg p-4 mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-medium text-[#3a6f78]">Recipients</h3>
            <p className="text-sm text-[#3a6f78]/80">
              {contacts.length} contact{contacts.length !== 1 ? 's' : ''} will receive this message via WhatsApp
            </p>
          </div>
          {contacts.length === 0 && (
            <div className="text-sm text-orange-600 bg-orange-100 px-3 py-1 rounded-full">
              No contacts added
            </div>
          )}
        </div>
      </div>

      <div className="space-y-6">
        {/* Message Input */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Message Content
          </label>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3a6f78] focus:border-transparent resize-none transition-all duration-200"
            rows={6}
            placeholder="Type your WhatsApp message here..."
            disabled={loading}
          />
          <div className="text-right text-sm text-gray-500 mt-1">
            {message.length} characters
          </div>
        </div>

        {/* File Attachments */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Attachments (Images, Videos, PDFs, Documents)
          </label>
          
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-[#3a6f78] transition-all duration-200 hover:bg-[#3a6f78]/5">
            <input
              type="file"
              multiple
              onChange={handleFileSelect}
              className="hidden"
              id="file-upload"
              accept="image/*,video/*,application/pdf,.doc,.docx,.txt"
              disabled={loading}
            />
            <label htmlFor="file-upload" className={`cursor-pointer ${loading ? 'pointer-events-none opacity-50' : ''}`}>
              <Paperclip size={32} className="mx-auto mb-2 text-gray-400" />
              <p className="text-gray-600 mb-1">Click to attach files</p>
              <p className="text-sm text-gray-500">Supports images, videos, PDFs, and documents</p>
            </label>
          </div>

          {attachedFiles.length > 0 && (
            <div className="mt-4 space-y-2">
              <h4 className="font-medium text-gray-700">Attached Files ({attachedFiles.length})</h4>
              {attachedFiles.map((file, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200 hover:border-[#3a6f78]/30 transition-all duration-200">
                  <div className="flex items-center gap-3">
                    {getFileIcon(file)}
                    <div>
                      <p className="font-medium text-gray-900">{file.name}</p>
                      <p className="text-sm text-gray-500">{formatFileSize(file.size)}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {canPreviewFile(file) && (
                      <button
                        onClick={() => {
                          setPreviewFile(file);
                          setShowPreview(true);
                        }}
                        disabled={loading}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg disabled:opacity-50 transition-all duration-200 transform hover:scale-110"
                      >
                        <Eye size={16} />
                      </button>
                    )}
                    <button
                      onClick={() => handleRemoveFile(index)}
                      disabled={loading}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg disabled:opacity-50 transition-all duration-200 transform hover:scale-110"
                    >
                      <X size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Send Button */}
        <div className="flex justify-end">
          <button
            onClick={handleSend}
            disabled={loading || (!message.trim() && attachedFiles.length === 0) || contacts.length === 0}
            className="flex items-center gap-2 bg-[#3a6f78] text-white px-8 py-3 rounded-lg hover:bg-[#2d5a63] disabled:bg-gray-300 disabled:cursor-not-allowed transition-all duration-200 font-medium transform hover:scale-105 shadow-lg hover:shadow-xl"
          >
            <Send size={16} />
            {loading ? 'Sending via WhatsApp...' : `Send to ${contacts.length} Contact${contacts.length !== 1 ? 's' : ''}`}
          </button>
        </div>
      </div>

      {/* File Preview Modal */}
      {showPreview && previewFile && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bg-white rounded-lg max-w-4xl max-h-[90vh] overflow-auto shadow-2xl">
            <div className="flex items-center justify-between p-4 border-b bg-[#3a6f78]/5">
              <h3 className="font-medium text-[#3a6f78]">{previewFile.name}</h3>
              <button
                onClick={() => {
                  setShowPreview(false);
                  setPreviewFile(null);
                }}
                className="p-2 hover:bg-gray-100 rounded-lg transition-all duration-200 transform hover:scale-110"
              >
                <X size={20} />
              </button>
            </div>
            <div className="p-4">
              {renderPreview()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MessageComposer;