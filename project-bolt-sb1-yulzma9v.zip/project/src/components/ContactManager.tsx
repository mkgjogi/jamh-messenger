import React, { useState } from 'react';
import { Plus, Upload, Download, Trash2, Users, Phone, User, AlertCircle } from 'lucide-react';
import type { Contact } from '../lib/supabase';

interface ContactManagerProps {
  contacts: Contact[];
  onAddContact: (contact: { name: string; phone: string }) => Promise<Contact>;
  onDeleteContact: (contactId: string) => Promise<void>;
  onAddBulkContacts: (contacts: { name: string; phone: string }[]) => Promise<Contact[]>;
}

const ContactManager: React.FC<ContactManagerProps> = ({ 
  contacts, 
  onAddContact, 
  onDeleteContact,
  onAddBulkContacts
}) => {
  const [newContact, setNewContact] = useState({ name: '', phone: '' });
  const [bulkInput, setBulkInput] = useState('');
  const [showBulkAdd, setShowBulkAdd] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAddSingleContact = async () => {
    if (newContact.name && newContact.phone) {
      try {
        setLoading(true);
        setError(null);
        await onAddContact(newContact);
        setNewContact({ name: '', phone: '' });
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to add contact');
      } finally {
        setLoading(false);
      }
    }
  };

  const handleBulkAdd = async () => {
    const lines = bulkInput.split('\n').filter(line => line.trim());
    const newContacts = lines.map(line => {
      const [name, phone] = line.split(',').map(item => item.trim());
      return { name: name || 'Unknown', phone: phone || '' };
    }).filter(contact => contact.phone);

    if (newContacts.length === 0) {
      setError('No valid contacts found in bulk input');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      await onAddBulkContacts(newContacts);
      setBulkInput('');
      setShowBulkAdd(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add contacts');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteContact = async (contactId: string) => {
    try {
      setLoading(true);
      setError(null);
      await onDeleteContact(contactId);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete contact');
    } finally {
      setLoading(false);
    }
  };

  const handleExportContacts = () => {
    const csv = contacts.map(contact => `${contact.name},${contact.phone}`).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'contacts.csv';
    a.click();
  };

  const getStatusColor = (status: Contact['status']) => {
    switch (status) {
      case 'sent': return 'bg-blue-100 text-blue-800';
      case 'delivered': return 'bg-emerald-100 text-emerald-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Users className="text-[#3a6f78]" size={24} />
          <h2 className="text-2xl font-bold text-gray-900">Contact Management</h2>
        </div>
        <div className="text-sm text-gray-500">
          Total Contacts: <span className="font-semibold text-[#3a6f78]">{contacts.length}</span>
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-center gap-2">
          <AlertCircle size={20} className="text-red-600" />
          <p className="text-red-700">{error}</p>
          <button 
            onClick={() => setError(null)}
            className="ml-auto text-red-600 hover:text-red-800"
          >
            ×
          </button>
        </div>
      )}

      {/* Add Contact Section */}
      <div className="bg-gradient-to-r from-[#3a6f78]/5 to-[#3a6f78]/10 rounded-lg p-6 mb-6 border border-[#3a6f78]/20">
        <h3 className="text-lg font-semibold mb-4 text-[#3a6f78]">Add New Contacts</h3>
        
        {!showBulkAdd ? (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <User size={16} className="inline mr-1" />
                  Contact Name
                </label>
                <input
                  type="text"
                  value={newContact.name}
                  onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3a6f78] focus:border-transparent transition-all duration-200"
                  placeholder="Enter contact name"
                  disabled={loading}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Phone size={16} className="inline mr-1" />
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={newContact.phone}
                  onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3a6f78] focus:border-transparent transition-all duration-200"
                  placeholder="Enter phone number"
                  disabled={loading}
                />
              </div>
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={handleAddSingleContact}
                disabled={loading || !newContact.name || !newContact.phone}
                className="flex items-center gap-2 bg-[#3a6f78] text-white px-4 py-2 rounded-lg hover:bg-[#2d5a63] disabled:bg-gray-300 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-105 shadow-md hover:shadow-lg"
              >
                <Plus size={16} />
                {loading ? 'Adding...' : 'Add Contact'}
              </button>
              <button
                onClick={() => setShowBulkAdd(true)}
                disabled={loading}
                className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:bg-gray-300 transition-all duration-200 transform hover:scale-105 shadow-md hover:shadow-lg"
              >
                <Upload size={16} />
                Bulk Add
              </button>
              <button
                onClick={handleExportContacts}
                disabled={contacts.length === 0}
                className="flex items-center gap-2 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 disabled:bg-gray-300 transition-all duration-200 transform hover:scale-105 shadow-md hover:shadow-lg"
              >
                <Download size={16} />
                Export CSV
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Bulk Add Contacts (Name, Phone - one per line)
              </label>
              <textarea
                value={bulkInput}
                onChange={(e) => setBulkInput(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3a6f78] focus:border-transparent transition-all duration-200"
                rows={6}
                placeholder="John Doe, +1234567890&#10;Jane Smith, +0987654321&#10;..."
                disabled={loading}
              />
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={handleBulkAdd}
                disabled={loading || !bulkInput.trim()}
                className="flex items-center gap-2 bg-[#3a6f78] text-white px-4 py-2 rounded-lg hover:bg-[#2d5a63] disabled:bg-gray-300 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-105 shadow-md hover:shadow-lg"
              >
                <Plus size={16} />
                {loading ? 'Adding...' : 'Add All Contacts'}
              </button>
              <button
                onClick={() => {
                  setShowBulkAdd(false);
                  setBulkInput('');
                  setError(null);
                }}
                disabled={loading}
                className="flex items-center gap-2 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 disabled:bg-gray-300 transition-all duration-200 transform hover:scale-105 shadow-md hover:shadow-lg"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Contacts List */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-[#3a6f78]">Contact List</h3>
        
        {contacts.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <Users size={48} className="mx-auto mb-4 text-gray-300" />
            <p className="text-lg">No contacts added yet</p>
            <p className="text-sm">Start by adding your first contact above</p>
          </div>
        ) : (
          <div className="grid gap-3">
            {contacts.map((contact) => (
              <div key={contact.id} className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg hover:shadow-md transition-all duration-200 hover:border-[#3a6f78]/30">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#3a6f78]/10 rounded-full flex items-center justify-center">
                    <User size={16} className="text-[#3a6f78]" />
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">{contact.name}</h4>
                    <p className="text-sm text-gray-500">{contact.phone}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(contact.status)}`}>
                    {contact.status}
                  </span>
                  <button
                    onClick={() => handleDeleteContact(contact.id)}
                    disabled={loading}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-110"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ContactManager;