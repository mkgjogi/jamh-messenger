import React from 'react';
import { MessageSquare } from 'lucide-react';

const LoadingSpinner: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
      <div className="text-center">
        <div className="relative">
          <div className="w-16 h-16 bg-[#3a6f78] rounded-full animate-pulse flex items-center justify-center mb-4 mx-auto">
            <MessageSquare size={24} className="text-white" />
          </div>
          <div className="absolute inset-0 w-16 h-16 border-4 border-[#3a6f78]/30 border-t-[#3a6f78] rounded-full animate-spin mx-auto"></div>
        </div>
        <h2 className="text-xl font-semibold text-[#3a6f78] mb-2">JOGI WhatsApp Messenger</h2>
        <p className="text-gray-600">Connecting to database...</p>
      </div>
    </div>
  );
};

export default LoadingSpinner;