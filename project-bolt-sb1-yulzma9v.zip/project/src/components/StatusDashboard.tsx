import React from 'react';
import { BarChart3, MessageSquare, Users, CheckCircle, XCircle, Clock, TrendingUp } from 'lucide-react';
import type { Contact, Message } from '../lib/supabase';

interface StatusDashboardProps {
  contacts: Contact[];
  messages: Message[];
}

const StatusDashboard: React.FC<StatusDashboardProps> = ({ contacts, messages }) => {
  const totalContacts = contacts.length;
  const sentMessages = contacts.filter(c => c.status === 'sent').length;
  const deliveredMessages = contacts.filter(c => c.status === 'delivered').length;
  const failedMessages = contacts.filter(c => c.status === 'failed').length;
  const pendingMessages = contacts.filter(c => c.status === 'pending').length;

  const totalMessagesCount = messages.length;
  const deliveryRate = totalContacts > 0 ? (deliveredMessages / totalContacts * 100).toFixed(1) : '0';

  const StatCard = ({ 
    icon: Icon, 
    title, 
    value, 
    subtitle, 
    color = 'teal' 
  }: { 
    icon: React.ComponentType<any>, 
    title: string, 
    value: string | number, 
    subtitle?: string, 
    color?: string 
  }) => {
    const colorClasses = {
      teal: 'bg-[#3a6f78]/10 border-[#3a6f78]/20 text-[#3a6f78]',
      blue: 'bg-blue-50 border-blue-200 text-blue-800',
      orange: 'bg-orange-50 border-orange-200 text-orange-800',
      red: 'bg-red-50 border-red-200 text-red-800',
      emerald: 'bg-emerald-50 border-emerald-200 text-emerald-800'
    };

    return (
      <div className={`p-6 rounded-lg border ${colorClasses[color as keyof typeof colorClasses] || colorClasses.teal} transition-all duration-200 hover:shadow-md transform hover:scale-105`}>
        <div className="flex items-center gap-3">
          <Icon size={24} />
          <div>
            <h3 className="font-medium">{title}</h3>
            <div className="text-2xl font-bold mt-1">{value}</div>
            {subtitle && <p className="text-sm opacity-75 mt-1">{subtitle}</p>}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="p-6">
      <div className="flex items-center gap-2 mb-6">
        <BarChart3 className="text-[#3a6f78]" size={24} />
        <h2 className="text-2xl font-bold text-gray-900">Dashboard & Analytics</h2>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          icon={Users}
          title="Total Contacts"
          value={totalContacts}
          subtitle="Active recipients"
          color="blue"
        />
        
        <StatCard
          icon={MessageSquare}
          title="Messages Sent"
          value={totalMessagesCount}
          subtitle="Total campaigns"
          color="teal"
        />
        
        <StatCard
          icon={CheckCircle}
          title="Delivery Rate"
          value={`${deliveryRate}%`}
          subtitle="Success percentage"
          color="emerald"
        />
        
        <StatCard
          icon={TrendingUp}
          title="Pending"
          value={pendingMessages}
          subtitle="Awaiting delivery"
          color="orange"
        />
      </div>

      {/* Detailed Status */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Message Status Breakdown */}
        <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm hover:shadow-md transition-all duration-200">
          <h3 className="text-lg font-semibold mb-4 text-[#3a6f78]">Message Status Breakdown</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200 hover:shadow-sm transition-all duration-200">
              <div className="flex items-center gap-2">
                <Clock size={16} className="text-blue-600" />
                <span className="font-medium">Sent</span>
              </div>
              <span className="text-blue-600 font-semibold">{sentMessages}</span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-emerald-50 rounded-lg border border-emerald-200 hover:shadow-sm transition-all duration-200">
              <div className="flex items-center gap-2">
                <CheckCircle size={16} className="text-emerald-600" />
                <span className="font-medium">Delivered</span>
              </div>
              <span className="text-emerald-600 font-semibold">{deliveredMessages}</span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200 hover:shadow-sm transition-all duration-200">
              <div className="flex items-center gap-2">
                <XCircle size={16} className="text-red-600" />
                <span className="font-medium">Failed</span>
              </div>
              <span className="text-red-600 font-semibold">{failedMessages}</span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg border border-orange-200 hover:shadow-sm transition-all duration-200">
              <div className="flex items-center gap-2">
                <Clock size={16} className="text-orange-600" />
                <span className="font-medium">Pending</span>
              </div>
              <span className="text-orange-600 font-semibold">{pendingMessages}</span>
            </div>
          </div>
        </div>

        {/* Recent Messages */}
        <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm hover:shadow-md transition-all duration-200">
          <h3 className="text-lg font-semibold mb-4 text-[#3a6f78]">Recent Messages</h3>
          
          {messages.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <MessageSquare size={32} className="mx-auto mb-2 text-gray-300" />
              <p>No messages sent yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {messages.slice(0, 5).map((message) => (
                <div key={message.id} className="p-3 bg-gray-50 rounded-lg border border-gray-200 hover:border-[#3a6f78]/30 transition-all duration-200">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {message.text || 'Media message'}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(message.created_at).toLocaleString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium text-[#3a6f78]">
                        {message.sent_count} sent
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Performance Insights */}
      <div className="mt-8 bg-gradient-to-r from-[#3a6f78]/10 to-[#3a6f78]/5 border border-[#3a6f78]/20 rounded-lg p-6">
        <h3 className="text-lg font-semibold mb-2 text-[#3a6f78]">Performance Insights</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div>
            <span className="font-medium text-[#3a6f78]">Best Time:</span>
            <p className="text-gray-600">10 AM - 2 PM typically shows higher engagement</p>
          </div>
          <div>
            <span className="font-medium text-blue-700">Message Length:</span>
            <p className="text-gray-600">Keep messages under 160 characters for best results</p>
          </div>
          <div>
            <span className="font-medium text-purple-700">Media Impact:</span>
            <p className="text-gray-600">Messages with images have 30% higher engagement</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatusDashboard;