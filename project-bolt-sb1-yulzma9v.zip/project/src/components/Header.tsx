import React from 'react';
import { MessageSquare, Zap } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-[#3a6f78] to-[#2d5a63] text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-lg backdrop-blur-sm">
              <MessageSquare size={24} />
            </div>
            <div>
              <h1 className="text-xl font-bold">JOGI WhatsApp Messenger</h1>
              <p className="text-[#a8d0d7] text-sm">Bulk Messaging Made Easy</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-lg backdrop-blur-sm">
            <Zap size={16} className="text-yellow-300" />
            <span className="text-sm font-medium">Pro Version</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;