import React, { useState } from 'react';
import { Settings, Key, Phone, CheckCircle, AlertCircle, ExternalLink } from 'lucide-react';

interface WhatsAppSetupProps {
  onSetupComplete: () => void;
}

const WhatsAppSetup: React.FC<WhatsAppSetupProps> = ({ onSetupComplete }) => {
  const [step, setStep] = useState(1);
  const [credentials, setCredentials] = useState({
    accessToken: '',
    phoneNumberId: '',
    businessAccountId: '',
    webhookToken: ''
  });

  const handleSaveCredentials = () => {
    // In a real app, you would save these to your backend securely
    localStorage.setItem('whatsapp_credentials', JSON.stringify(credentials));
    onSetupComplete();
  };

  const steps = [
    {
      title: 'Create Facebook Developer Account',
      description: 'Sign up for a Facebook Developer account and create a new app',
      action: 'Go to Facebook Developers',
      url: 'https://developers.facebook.com/'
    },
    {
      title: 'Set up WhatsApp Business API',
      description: 'Add WhatsApp Business API to your Facebook app',
      action: 'Configure WhatsApp',
      url: 'https://developers.facebook.com/docs/whatsapp/getting-started'
    },
    {
      title: 'Get Your Credentials',
      description: 'Copy your access token, phone number ID, and business account ID',
      action: 'Enter Credentials',
      url: null
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#3a6f78] to-[#2d5a63] text-white p-6">
          <div className="flex items-center gap-3">
            <Settings size={24} />
            <div>
              <h1 className="text-2xl font-bold">WhatsApp Business API Setup</h1>
              <p className="text-[#a8d0d7]">Configure your WhatsApp Business API to start sending messages</p>
            </div>
          </div>
        </div>

        <div className="p-6">
          {/* Progress Steps */}
          <div className="flex items-center justify-between mb-8">
            {steps.map((_, index) => (
              <div key={index} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  index + 1 <= step 
                    ? 'bg-[#3a6f78] text-white' 
                    : 'bg-gray-200 text-gray-600'
                }`}>
                  {index + 1 <= step ? <CheckCircle size={16} /> : index + 1}
                </div>
                {index < steps.length - 1 && (
                  <div className={`w-16 h-1 mx-2 ${
                    index + 1 < step ? 'bg-[#3a6f78]' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>

          {/* Current Step Content */}
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-xl font-semibold text-gray-900 mb-2">
                Step {step}: {steps[step - 1].title}
              </h2>
              <p className="text-gray-600">
                {steps[step - 1].description}
              </p>
            </div>

            {step < 3 && (
              <div className="text-center">
                <a
                  href={steps[step - 1].url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-[#3a6f78] text-white px-6 py-3 rounded-lg hover:bg-[#2d5a63] transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl"
                >
                  <ExternalLink size={16} />
                  {steps[step - 1].action}
                </a>
                <div className="mt-4">
                  <button
                    onClick={() => setStep(step + 1)}
                    className="text-[#3a6f78] hover:text-[#2d5a63] font-medium"
                  >
                    I've completed this step →
                  </button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4 max-w-md mx-auto">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Key size={16} className="inline mr-1" />
                    Access Token
                  </label>
                  <input
                    type="password"
                    value={credentials.accessToken}
                    onChange={(e) => setCredentials({...credentials, accessToken: e.target.value})}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3a6f78] focus:border-transparent"
                    placeholder="Enter your WhatsApp access token"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Phone size={16} className="inline mr-1" />
                    Phone Number ID
                  </label>
                  <input
                    type="text"
                    value={credentials.phoneNumberId}
                    onChange={(e) => setCredentials({...credentials, phoneNumberId: e.target.value})}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3a6f78] focus:border-transparent"
                    placeholder="Enter your phone number ID"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Business Account ID
                  </label>
                  <input
                    type="text"
                    value={credentials.businessAccountId}
                    onChange={(e) => setCredentials({...credentials, businessAccountId: e.target.value})}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3a6f78] focus:border-transparent"
                    placeholder="Enter your business account ID"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Webhook Verify Token
                  </label>
                  <input
                    type="text"
                    value={credentials.webhookToken}
                    onChange={(e) => setCredentials({...credentials, webhookToken: e.target.value})}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#3a6f78] focus:border-transparent"
                    placeholder="Create a webhook verify token"
                  />
                </div>

                <button
                  onClick={handleSaveCredentials}
                  disabled={!credentials.accessToken || !credentials.phoneNumberId}
                  className="w-full bg-[#3a6f78] text-white py-3 rounded-lg hover:bg-[#2d5a63] disabled:bg-gray-300 disabled:cursor-not-allowed transition-all duration-200 font-medium transform hover:scale-105 shadow-lg hover:shadow-xl"
                >
                  Complete Setup
                </button>
              </div>
            )}
          </div>

          {/* Warning */}
          <div className="mt-8 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex items-start gap-2">
              <AlertCircle size={20} className="text-yellow-600 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-yellow-800">Important Notes:</p>
                <ul className="mt-1 text-yellow-700 space-y-1">
                  <li>• WhatsApp Business API requires approval for production use</li>
                  <li>• Test with a small number of contacts first</li>
                  <li>• Ensure you comply with WhatsApp's messaging policies</li>
                  <li>• Keep your credentials secure and never share them</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WhatsAppSetup;