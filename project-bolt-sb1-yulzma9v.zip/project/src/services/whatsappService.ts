import { supabase } from '../lib/supabase';
import type { Contact } from '../lib/supabase';

export interface SendMessageRequest {
  contacts: Contact[];
  message: {
    text: string;
    attachments?: File[];
  };
}

export interface SendMessageResponse {
  success: boolean;
  results: Array<{
    contactId: string;
    phone: string;
    status: 'sent' | 'failed';
    messageId?: string;
    error?: string;
  }>;
  summary: {
    total: number;
    sent: number;
    delivered: number;
    failed: number;
  };
  messageId?: string;
  error?: string;
}

export class WhatsAppService {
  private static instance: WhatsAppService;
  
  public static getInstance(): WhatsAppService {
    if (!WhatsAppService.instance) {
      WhatsAppService.instance = new WhatsAppService();
    }
    return WhatsAppService.instance;
  }

  async uploadAttachment(file: File): Promise<string> {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `attachments/${fileName}`;

      const { data, error } = await supabase.storage
        .from('message-attachments')
        .upload(filePath, file);

      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage
        .from('message-attachments')
        .getPublicUrl(filePath);

      return publicUrl;
    } catch (error) {
      console.error('Error uploading attachment:', error);
      throw new Error('Failed to upload attachment');
    }
  }

  async sendMessage(request: SendMessageRequest): Promise<SendMessageResponse> {
    try {
      // Upload attachments if any
      const attachments = [];
      if (request.message.attachments && request.message.attachments.length > 0) {
        for (const file of request.message.attachments) {
          const url = await this.uploadAttachment(file);
          attachments.push({
            type: file.type,
            url: url,
            filename: file.name
          });
        }
      }

      // Call the edge function
      const { data, error } = await supabase.functions.invoke('send-whatsapp-message', {
        body: {
          contacts: request.contacts.map(contact => ({
            id: contact.id,
            name: contact.name,
            phone: contact.phone
          })),
          message: {
            text: request.message.text,
            attachments: attachments
          }
        }
      });

      if (error) throw error;

      return data;
    } catch (error) {
      console.error('Error sending WhatsApp message:', error);
      return {
        success: false,
        error: error.message || 'Failed to send message',
        results: [],
        summary: {
          total: request.contacts.length,
          sent: 0,
          delivered: 0,
          failed: request.contacts.length
        }
      };
    }
  }

  async getMessageStatus(messageId: string): Promise<any> {
    try {
      // This would typically query your message tracking system
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('id', messageId)
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error getting message status:', error);
      throw error;
    }
  }
}

export const whatsappService = WhatsAppService.getInstance();