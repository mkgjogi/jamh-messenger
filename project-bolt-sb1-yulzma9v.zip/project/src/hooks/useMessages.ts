import { useState, useEffect } from 'react';
import { supabase, type Message } from '../lib/supabase';

export const useMessages = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch messages from database
  const fetchMessages = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setMessages(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch messages');
    } finally {
      setLoading(false);
    }
  };

  // Add new message
  const addMessage = async (messageData: {
    text: string;
    sent_count: number;
    delivered_count?: number;
    failed_count?: number;
  }) => {
    try {
      const { data, error } = await supabase
        .from('messages')
        .insert([{
          ...messageData,
          delivered_count: messageData.delivered_count || 0,
          failed_count: messageData.failed_count || 0
        }])
        .select()
        .single();

      if (error) throw error;
      setMessages(prev => [data, ...prev]);
      return data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add message');
      throw err;
    }
  };

  // Update message stats
  const updateMessageStats = async (
    messageId: string, 
    stats: { sent_count?: number; delivered_count?: number; failed_count?: number }
  ) => {
    try {
      const { data, error } = await supabase
        .from('messages')
        .update(stats)
        .eq('id', messageId)
        .select()
        .single();

      if (error) throw error;
      setMessages(prev => 
        prev.map(message => 
          message.id === messageId ? { ...message, ...stats } : message
        )
      );
      return data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update message');
      throw err;
    }
  };

  useEffect(() => {
    fetchMessages();
  }, []);

  return {
    messages,
    loading,
    error,
    addMessage,
    updateMessageStats,
    refetch: fetchMessages
  };
};