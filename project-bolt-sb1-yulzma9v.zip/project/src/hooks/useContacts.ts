import { useState, useEffect } from 'react';
import { supabase, type Contact } from '../lib/supabase';

export const useContacts = () => {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch contacts from database
  const fetchContacts = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('contacts')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setContacts(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch contacts');
    } finally {
      setLoading(false);
    }
  };

  // Add new contact
  const addContact = async (contactData: { name: string; phone: string }) => {
    try {
      const { data, error } = await supabase
        .from('contacts')
        .insert([contactData])
        .select()
        .single();

      if (error) throw error;
      setContacts(prev => [data, ...prev]);
      return data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add contact');
      throw err;
    }
  };

  // Update contact status
  const updateContactStatus = async (contactId: string, status: Contact['status']) => {
    try {
      const { data, error } = await supabase
        .from('contacts')
        .update({ status })
        .eq('id', contactId)
        .select()
        .single();

      if (error) throw error;
      setContacts(prev => 
        prev.map(contact => 
          contact.id === contactId ? { ...contact, status } : contact
        )
      );
      return data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update contact');
      throw err;
    }
  };

  // Delete contact
  const deleteContact = async (contactId: string) => {
    try {
      const { error } = await supabase
        .from('contacts')
        .delete()
        .eq('id', contactId);

      if (error) throw error;
      setContacts(prev => prev.filter(contact => contact.id !== contactId));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete contact');
      throw err;
    }
  };

  // Bulk add contacts
  const addBulkContacts = async (contactsData: { name: string; phone: string }[]) => {
    try {
      const { data, error } = await supabase
        .from('contacts')
        .insert(contactsData)
        .select();

      if (error) throw error;
      setContacts(prev => [...(data || []), ...prev]);
      return data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add contacts');
      throw err;
    }
  };

  useEffect(() => {
    fetchContacts();
  }, []);

  return {
    contacts,
    loading,
    error,
    addContact,
    updateContactStatus,
    deleteContact,
    addBulkContacts,
    refetch: fetchContacts
  };
};