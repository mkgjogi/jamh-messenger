import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import ContactManager from './components/ContactManager';
import MessageComposer from './components/MessageComposer';
import StatusDashboard from './components/StatusDashboard';
import LoadingSpinner from './components/LoadingSpinner';
import WhatsAppSetup from './components/WhatsAppSetup';
import { MessageSquare, Users, BarChart3 } from 'lucide-react';
import { useContacts } from './hooks/useContacts';
import { useMessages } from './hooks/useMessages';
import { whatsappService } from './services/whatsappService';

function App() {
  const [activeTab, setActiveTab] = useState<'compose' | 'contacts' | 'dashboard'>('compose');
  const [isWhatsAppSetup, setIsWhatsAppSetup] = useState(false);
  const [sendingMessage, setSendingMessage] = useState(false);
  
  const {
    contacts,
    loading: contactsLoading,
    error: contactsError,
    addContact,
    updateContactStatus,
    deleteContact,
    addBulkContacts,
    refetch: refetchContacts
  } = useContacts();

  const {
    messages,
    loading: messagesLoading,
    error: messagesError,
    addMessage,
    refetch: refetchMessages
  } = useMessages();

  // Check if WhatsApp is set up
  useEffect(() => {
    const credentials = localStorage.getItem('whatsapp_credentials');
    setIsWhatsAppSetup(!!credentials);
  }, []);

  const handleSendMessage = async (messageData: { text: string; files: File[] }) => {
    if (contacts.length === 0) {
      throw new Error('No contacts available to send message to');
    }

    try {
      setSendingMessage(true);

      // Send message via WhatsApp service
      const result = await whatsappService.sendMessage({
        contacts,
        message: {
          text: messageData.text,
          attachments: messageData.files
        }
      });

      if (!result.success) {
        throw new Error(result.error || 'Failed to send message');
      }

      // Refresh contacts and messages to get updated status
      await Promise.all([refetchContacts(), refetchMessages()]);

      return result;

    } catch (error) {
      console.error('Failed to send message:', error);
      throw error;
    } finally {
      setSendingMessage(false);
    }
  };

  const TabButton = ({ 
    tab, 
    icon: Icon, 
    label, 
    isActive 
  }: { 
    tab: typeof activeTab, 
    icon: React.ComponentType<any>, 
    label: string, 
    isActive: boolean 
  }) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all duration-300 transform hover:scale-105 ${
        isActive
          ? 'bg-[#3a6f78] text-white shadow-lg shadow-[#3a6f78]/30'
          : 'bg-white text-gray-600 hover:bg-gray-50 hover:text-[#3a6f78] hover:shadow-md'
      }`}
    >
      <Icon size={20} />
      {label}
    </button>
  );

  // Show setup screen if WhatsApp is not configured
  if (!isWhatsAppSetup) {
    return <WhatsAppSetup onSetupComplete={() => setIsWhatsAppSetup(true)} />;
  }

  if (contactsLoading || messagesLoading) {
    return <LoadingSpinner />;
  }

  if (contactsError || messagesError) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-lg border border-red-200">
          <h2 className="text-xl font-bold text-red-600 mb-4">Database Connection Error</h2>
          <p className="text-gray-600 mb-4">
            {contactsError || messagesError}
          </p>
          <button 
            onClick={() => window.location.reload()} 
            className="bg-[#3a6f78] text-white px-4 py-2 rounded-lg hover:bg-[#2d5a63] transition-colors"
          >
            Retry Connection
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-4 mb-8">
          <TabButton
            tab="compose"
            icon={MessageSquare}
            label="Compose Message"
            isActive={activeTab === 'compose'}
          />
          <TabButton
            tab="contacts"
            icon={Users}
            label="Manage Contacts"
            isActive={activeTab === 'contacts'}
          />
          <TabButton
            tab="dashboard"
            icon={BarChart3}
            label="Dashboard"
            isActive={activeTab === 'dashboard'}
          />
        </div>

        {/* Content Area */}
        <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden backdrop-blur-sm">
          {activeTab === 'compose' && (
            <MessageComposer 
              contacts={contacts}
              onSendMessage={handleSendMessage}
              loading={sendingMessage}
            />
          )}
          
          {activeTab === 'contacts' && (
            <ContactManager 
              contacts={contacts}
              onAddContact={addContact}
              onDeleteContact={deleteContact}
              onAddBulkContacts={addBulkContacts}
            />
          )}
          
          {activeTab === 'dashboard' && (
            <StatusDashboard 
              contacts={contacts}
              messages={messages}
            />
          )}
        </div>
      </div>
    </div>
  );
}

export default App;