import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'npm:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  const supabaseClient = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  )

  try {
    if (req.method === 'GET') {
      // Webhook verification
      const url = new URL(req.url)
      const mode = url.searchParams.get('hub.mode')
      const token = url.searchParams.get('hub.verify_token')
      const challenge = url.searchParams.get('hub.challenge')
      
      const verifyToken = Deno.env.get('WHATSAPP_WEBHOOK_VERIFY_TOKEN')
      
      if (mode === 'subscribe' && token === verifyToken) {
        console.log('Webhook verified successfully!')
        return new Response(challenge, { status: 200 })
      } else {
        return new Response('Forbidden', { status: 403 })
      }
    }

    if (req.method === 'POST') {
      // Handle webhook notifications
      const body = await req.json()
      
      console.log('Webhook received:', JSON.stringify(body, null, 2))
      
      // Process webhook data
      if (body.object === 'whatsapp_business_account') {
        for (const entry of body.entry || []) {
          for (const change of entry.changes || []) {
            if (change.field === 'messages') {
              const value = change.value
              
              // Handle message status updates
              if (value.statuses) {
                for (const status of value.statuses) {
                  const messageId = status.id
                  const statusType = status.status // sent, delivered, read, failed
                  const recipientId = status.recipient_id
                  
                  console.log(`Message ${messageId} to ${recipientId}: ${statusType}`)
                  
                  // Update contact status based on message status
                  if (statusType === 'delivered') {
                    await supabaseClient
                      .from('contacts')
                      .update({ status: 'delivered' })
                      .eq('phone', recipientId)
                  } else if (statusType === 'failed') {
                    await supabaseClient
                      .from('contacts')
                      .update({ status: 'failed' })
                      .eq('phone', recipientId)
                  }
                }
              }
              
              // Handle incoming messages (optional - for replies)
              if (value.messages) {
                for (const message of value.messages) {
                  console.log('Incoming message:', message)
                  // You can store incoming messages or handle replies here
                }
              }
            }
          }
        }
      }
      
      return new Response('OK', { status: 200 })
    }

    return new Response('Method not allowed', { status: 405 })

  } catch (error) {
    console.error('Webhook error:', error)
    return new Response('Internal Server Error', { status: 500 })
  }
})