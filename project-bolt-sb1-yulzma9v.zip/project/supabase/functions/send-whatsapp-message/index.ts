const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

interface WhatsAppMessageRequest {
  contacts: Array<{
    id: string;
    name: string;
    phone: string;
  }>;
  message: {
    text: string;
    attachments?: Array<{
      type: string;
      url: string;
      filename: string;
    }>;
  };
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Check for required environment variables
    const whatsappToken = Deno.env.get('WHATSAPP_ACCESS_TOKEN')
    const phoneNumberId = Deno.env.get('WHATSAPP_PHONE_NUMBER_ID')
    const supabaseUrl = Deno.env.get('SUPABASE_URL')
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    
    if (!whatsappToken || !phoneNumberId) {
      return new Response(
        JSON.stringify({
          success: false,
          error: 'WhatsApp API credentials not configured',
          details: {
            message: 'Please configure the following environment variables in your Supabase project:',
            required_variables: [
              'WHATSAPP_ACCESS_TOKEN',
              'WHATSAPP_PHONE_NUMBER_ID'
            ],
            instructions: 'Go to your Supabase Dashboard > Edge Functions > send-whatsapp-message > Settings to add these environment variables.'
          }
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400,
        }
      )
    }

    if (!supabaseUrl || !supabaseServiceKey) {
      return new Response(
        JSON.stringify({
          success: false,
          error: 'Supabase configuration missing',
          details: 'SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are required'
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 500,
        }
      )
    }

    const { createClient } = await import('npm:@supabase/supabase-js@2')
    const supabaseClient = createClient(supabaseUrl, supabaseServiceKey)

    const { contacts, message }: WhatsAppMessageRequest = await req.json()
    
    if (!contacts || !Array.isArray(contacts) || contacts.length === 0) {
      return new Response(
        JSON.stringify({
          success: false,
          error: 'No contacts provided'
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400,
        }
      )
    }

    if (!message || !message.text) {
      return new Response(
        JSON.stringify({
          success: false,
          error: 'Message text is required'
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400,
        }
      )
    }

    const results = []
    let sentCount = 0
    let deliveredCount = 0
    let failedCount = 0

    // Send messages to each contact
    for (const contact of contacts) {
      try {
        // Clean phone number (remove spaces, dashes, etc.)
        const cleanPhone = contact.phone.replace(/[^\d+]/g, '')
        
        if (!cleanPhone) {
          failedCount++
          results.push({
            contactId: contact.id,
            phone: contact.phone,
            status: 'failed',
            error: 'Invalid phone number format'
          })
          continue
        }
        
        let messagePayload: any = {
          messaging_product: "whatsapp",
          to: cleanPhone,
          type: "text",
          text: {
            body: message.text
          }
        }

        // If there are attachments, send them as media messages
        if (message.attachments && message.attachments.length > 0) {
          const attachment = message.attachments[0] // Send first attachment
          
          if (attachment.type.startsWith('image/')) {
            messagePayload = {
              messaging_product: "whatsapp",
              to: cleanPhone,
              type: "image",
              image: {
                link: attachment.url,
                caption: message.text
              }
            }
          } else if (attachment.type.startsWith('video/')) {
            messagePayload = {
              messaging_product: "whatsapp",
              to: cleanPhone,
              type: "video",
              video: {
                link: attachment.url,
                caption: message.text
              }
            }
          } else if (attachment.type === 'application/pdf') {
            messagePayload = {
              messaging_product: "whatsapp",
              to: cleanPhone,
              type: "document",
              document: {
                link: attachment.url,
                caption: message.text,
                filename: attachment.filename
              }
            }
          }
        }

        // Send message via WhatsApp Business API
        const response = await fetch(
          `https://graph.facebook.com/v18.0/${phoneNumberId}/messages`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${whatsappToken}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(messagePayload),
          }
        )

        const result = await response.json()

        if (response.ok && result.messages) {
          // Update contact status to 'sent'
          await supabaseClient
            .from('contacts')
            .update({ status: 'sent' })
            .eq('id', contact.id)
          
          sentCount++
          deliveredCount++ // Initially mark as delivered, webhook will update if failed
          
          results.push({
            contactId: contact.id,
            phone: cleanPhone,
            status: 'sent',
            messageId: result.messages[0].id
          })
        } else {
          // Update contact status to 'failed'
          await supabaseClient
            .from('contacts')
            .update({ status: 'failed' })
            .eq('id', contact.id)
          
          failedCount++
          
          results.push({
            contactId: contact.id,
            phone: cleanPhone,
            status: 'failed',
            error: result.error?.message || `HTTP ${response.status}: ${response.statusText}`
          })
        }

        // Add small delay between messages to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 100))

      } catch (error) {
        // Update contact status to 'failed'
        await supabaseClient
          .from('contacts')
          .update({ status: 'failed' })
          .eq('id', contact.id)
        
        failedCount++
        
        results.push({
          contactId: contact.id,
          phone: contact.phone,
          status: 'failed',
          error: error.message
        })
      }
    }

    // Save message to database
    const { data: messageData, error: messageError } = await supabaseClient
      .from('messages')
      .insert({
        text: message.text,
        sent_count: sentCount,
        delivered_count: deliveredCount,
        failed_count: failedCount
      })
      .select()
      .single()

    if (messageError) {
      console.error('Error saving message:', messageError)
    }

    return new Response(
      JSON.stringify({
        success: true,
        results,
        summary: {
          total: contacts.length,
          sent: sentCount,
          delivered: deliveredCount,
          failed: failedCount
        },
        messageId: messageData?.id
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )

  } catch (error) {
    console.error('Error in send-whatsapp-message function:', error)
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
        details: 'Check the function logs for more information'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    )
  }
})